/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Lluiz
 */
public class Alternativas {
    private int idAlternativas;
    private String Resposta;
    private int idExercicios;

    public int getIdAlternativas() {
        return idAlternativas;
    }

    public void setIdAlternativas(int idAlternativas) {
        this.idAlternativas = idAlternativas;
    }

    public String getResposta() {
        return Resposta;
    }

    public void setResposta(String Resposta) {
        this.Resposta = Resposta;
    }

    public int getIdExercicios() {
        return idExercicios;
    }

    public void setIdExercicios(int idExercicios) {
        this.idExercicios = idExercicios;
    }

    
}