
package Model;

public class Aluno {
        String nome;
    int idAluno;
    int perfil;
    Historico hist;
    Avaliacao ava;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(int idAluno) {
        this.idAluno = idAluno;
    }

    public int getPerfil() {
        return perfil;
    }

    public void setPerfil(int perfil) {
        this.perfil = perfil;
    }

    public Historico getHist() {
        return hist;
    }

    public void setHist(Historico hist) {
        this.hist = hist;
    }

    public Avaliacao getAva() {
        return ava;
    }

    public void setAva(Avaliacao ava) {
        this.ava = ava;
    }
    
    
    
    
}