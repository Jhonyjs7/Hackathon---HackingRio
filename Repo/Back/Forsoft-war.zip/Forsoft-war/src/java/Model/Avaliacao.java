
package Model;

/**
 *
 * @author Lluiz
 */
public class Avaliacao {
    int avaliacao;
    String nome;
    String descricao;
    int nota;
    String anexo;
    int idAluno;
    int idTurma;
}
