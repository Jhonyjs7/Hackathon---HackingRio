/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Lluiz
 */
public class Historico {
    int idHistorico;
    int idAluno;
    int idExercicios;
    boolean acerto;
    Exercicios ex;

    public int getIdHistorico() {
        return idHistorico;
    }

    public void setIdHistorico(int idHistorico) {
        this.idHistorico = idHistorico;
    }

    public int getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(int idAluno) {
        this.idAluno = idAluno;
    }

    public int getIdExercicios() {
        return idExercicios;
    }

    public void setIdExercicios(int idExercicios) {
        this.idExercicios = idExercicios;
    }

    public boolean isAcerto() {
        return acerto;
    }

    public void setAcerto(boolean acerto) {
        this.acerto = acerto;
    }

    public Exercicios getEx() {
        return ex;
    }

    public void setEx(Exercicios ex) {
        this.ex = ex;
    }
    
    
}
