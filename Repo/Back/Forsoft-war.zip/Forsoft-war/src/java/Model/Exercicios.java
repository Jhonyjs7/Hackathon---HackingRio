/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lluiz
 */
public class Exercicios {
    private int idExercicios;
    private String enunciado;

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }
    private int correta;
    private int idTurma;
    private int NivelExercicio;
    private int idAlternativas;
    private List<Alternativas> al = new ArrayList();
    private String tema;

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getIdExercicios() {
        return idExercicios;
    }

    public void setIdExercicios(int idExercicios) {
        this.idExercicios = idExercicios;
    }

    public int getCorreta() {
        return correta;
    }

    public void setCorreta(int correta) {
        this.correta = correta;
    }

    public int getIdTurma() {
        return idTurma;
    }

    public void setIdTurma(int idTurma) {
        this.idTurma = idTurma;
    }

    public int getIdAlternativas() {
        return idAlternativas;
    }

    public void setIdAlternativas(int idAlternativas) {
        this.idAlternativas = idAlternativas;
    }

    public Alternativas getAl(int i) {
        return al.get(i);
    }

    public void setAl(Alternativas al) {
        this.al.add(al);
    }

    public int getNivelExercicio() {
        return NivelExercicio;
    }

    public void setNivelExercicio(int NivelExercicio) {
        this.NivelExercicio = NivelExercicio;
    }

}