/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lluiz
 */
public class DaoProx {
    private Connection conexao;
       public DaoProx() throws ClassNotFoundException {
        ConnectionFactory cf = new ConnectionFactory(); // fazer a conexão com o banco
        conexao = cf.connect();
        
    }

    
  void PegarProximo(Aluno al,boolean acerto) throws SQLException{
          String sqle = "insert into Historico(idAluno, idExercicios, Acerto) values (?,?,?)";
        

PreparedStatement ps = conexao.prepareStatement(sqle,PreparedStatement.RETURN_GENERATED_KEYS);
 try{
            //ps.setInt(1, al.getIdAluno());
            //ps.setInt(2, al.getHist().getIdExercicios());
            ps.setBoolean(3, acerto);
            ps.executeUpdate();
            
            conexao.commit();
            ResultSet rs = ps.getGeneratedKeys();
                rs.next();
                String exercicio = "select * from Aluno a inner join Turma t on a.idAluno = t.idAluno inner join Exercicios ex on ex.idTurma = t.idTurma where a.idAluno = ?;";
              PreparedStatement psh = conexao.prepareStatement(exercicio);
              ResultSet rs2 = psh.executeQuery();

            
             
        }catch (SQLException exp){
            conexao.rollback();
        }
        finally{
            //Fecha as conexões não nulas
            if (ps != null) {
                ps.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        }                        
    }
           
}

