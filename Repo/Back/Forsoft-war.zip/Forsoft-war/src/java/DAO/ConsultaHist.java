/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author amanda
 */
public class ConsultaHist {
     private Connection conexao;

    public ConsultaHist() throws ClassNotFoundException {
        ConnectionFactory cf = new ConnectionFactory(); // fazer a conexão com o banco
        conexao = cf.connect();
    }
    
    public ResultSet carregarHistorico(int id) throws SQLException{
        int mediana;
        int indice;
        conexao.setAutoCommit(false);
        
        String sql = "select * from Historico h inner join Exercicios ex on h.idExercicios = ex.idExercicios where h.idAluno=? order by ex.NivelExercicio";
        
        PreparedStatement ps = conexao.prepareStatement(sql);
        
        ResultSet rset = ps.executeQuery();
    
       return rset ;
       
    }
    
    
    
}