/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lluiz
 */
public class CarregarProjeto {
     private Connection conexao;
       public CarregarProjeto() throws ClassNotFoundException {
        ConnectionFactory cf = new ConnectionFactory(); // fazer a conexão com o banco
        conexao = cf.connect(); 
    }
    
      public ResultSet Carregar(int id) throws SQLException{
          
          String sqle = "select * from Turma t inner join Avaliação av on t.idTurma = av.idTurma where t.idProfessor = ? and av.Status = false";
          
        conexao.setAutoCommit(false);

        PreparedStatement ps = conexao.prepareStatement(sqle);
        try{
            ps.setInt(1,id);
            ps.executeQuery();
            
            ResultSet rs = ps.executeQuery();
      
                return rs;
  
        }catch (SQLException exp){
            conexao.rollback();
        }                       
        return null;
    }
}
