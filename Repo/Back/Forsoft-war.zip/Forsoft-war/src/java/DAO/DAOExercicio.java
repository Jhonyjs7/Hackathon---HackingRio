/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Exercicios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author amanda
 */
public class DAOExercicio {
    
    private Connection conexao;

    public DAOExercicio() throws ClassNotFoundException {
        ConnectionFactory cf = new ConnectionFactory(); // fazer a conexão com o banco
        conexao = cf.connect();
    }
    
     public void cadastrarExercicios (Exercicios e, int flag) throws SQLException{
        conexao.setAutoCommit(false);
        
        String sql = "insert into Exercicio (IDTurma, Enunciado,NivelExercicio,Tema) values (?,?,?,?)"; 
        String alt = "insert into Alternativas (Correta,Resposta, IDExercicio) VALUES (?,?,?);";

        PreparedStatement ps = conexao.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        PreparedStatement psl = conexao.prepareStatement(alt,PreparedStatement.RETURN_GENERATED_KEYS);
  
        try{
            ps.setInt(1, e.getIdTurma());
            ps.setString(2, e.getEnunciado());
            ps.setInt(3, e.getNivelExercicio());
            ps.setString(4, e.getTema());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            for (int i=0; i<4;i++ ){
                if(flag == i){
                 psl.setBoolean(1,true);
                }else{
                 psl.setBoolean(1,false);
                }
               psl.setString(2, e.getAl(i).getResposta());  
               psl.setInt(3, id);
               psl.executeUpdate();
            }
            
            
            conexao.commit();
             
        }catch (SQLException exp){

            conexao.rollback();
        }
        
        finally{
            
            if (ps != null) {
                ps.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        }                        
    }
}