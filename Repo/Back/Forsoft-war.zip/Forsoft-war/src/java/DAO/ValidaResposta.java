/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Historico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lluiz
 */
public class ValidaResposta {
     private Connection conexao;
       public ValidaResposta() throws ClassNotFoundException {
        ConnectionFactory cf = new ConnectionFactory(); // fazer a conexão com o banco
        conexao = cf.connect();
        
    }

    
  public int Carregar(Historico h,int resp) throws SQLException{
          String sqle = "select * from Aluno a inner join Turma t on a.idAluno = t.idAluno inner join Exercicios ex on t.idTurma = ex.idTurma inner join Alternativas al on ex.idExercicios = al.idExercicios  where a.idAluno = ?";
        conexao.setAutoCommit(false);
        PreparedStatement ps = conexao.prepareStatement(sqle);
        try{
            ps.setInt(1,h.getIdAluno());
            ps.executeQuery();
            
            ResultSet rs = ps.executeQuery();
            rs.next();
            int correta;
            if (rs.getInt("Correta")==resp){
                 correta = 1;
            }else{
                 correta = 0;
  
            }
                String strInsert = "insert into historico ('idAluno','idExercicios','Acerto') values (?,?,?)";
                PreparedStatement psi = conexao.prepareStatement(strInsert,PreparedStatement.RETURN_GENERATED_KEYS);
                 try{
                psi.setInt(1, h.getIdAluno());
                psi.setInt(2, h.getIdExercicios());
                psi.setInt(3, correta);
                psi.executeUpdate();
                 }catch(SQLException exp){
                     conexao.rollback();
                 }
                 
                return correta;

            
             
        }catch (SQLException exp){
            conexao.rollback();
        }                       
        return 2;
    }
}
