/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.lang.reflect.Field;

/**
 *
 * @author Lluiz
 */
public class DaoGen {
    Class<?> classe;
    DaoGen(String nome) throws ClassNotFoundException{
    classe = Class.forName(nome);
         for (Field atributo : classe.getDeclaredFields()) {
            String nomeCampo = atributo.getName();
            
        }
    }
    public void get(String query){
        
    }
    public void post(){
        
    }
    public void put(){
        
    }
    
    public void remove(){
        
    }
    
}
