/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.ValidaResposta;
import Model.Historico;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lluiz
 */
public class ResponderExercicio extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
       try{
           Historico h = new Historico();
       h.setIdAluno(Integer.parseInt(request.getParameter("idExercicio")));
       int nivel = (Integer.parseInt(request.getParameter("p_nivel")));
       h.setIdExercicios((Integer.parseInt(request.getParameter("idExercicio"))));
       //int setAcerto = ((Integer.parseInt(request.getParameter("Acerto"))));
       h.setIdAluno(Integer.parseInt(request.getParameter("id")));
       int resp = Integer.parseInt(request.getParameter("resp"));
            ValidaResposta v = new ValidaResposta();
            int k = 2;
            k = v.Carregar(h, k);
            response.sendRedirect("questionario.jsp?correto="+k+"&NivelAnt="+nivel);
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ResponderExercicio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ResponderExercicio.class.getName()).log(Level.SEVERE, null, ex);
        }catch(NumberFormatException e){
            Logger.getLogger(ResponderExercicio.class.getName()).log(Level.SEVERE, null, e);
        }
       
    }


}
